import boto3, gzip, json, re, os

FIREHOSE_STREAM = os.environ['FIREHOSE_STREAM_NAME']
firehose  = boto3.client('firehose')
s3_client = boto3.client('s3')

# 공백 구분 + 따옴표 필드 파싱 (ALB 로그 포맷)
ALB_RE = re.compile(r'"[^"]*"|[^ ]+')

def parse_line(line):
    fields = ALB_RE.findall(line)
    if len(fields) < 13:
        return None
    status = fields[8].strip('"')
    level  = 'ERROR' if status.startswith('5') else 'WARN' if status.startswith('4') else 'INFO'
    try:
        resp_ms = int(float(fields[7]) * 1000)
    except (ValueError, IndexError):
        resp_ms = -1
    return {
        'timestamp':       fields[1].strip('"'),
        'category':        'Access',
        'service':         'alb',
        'level':           level,
        'elb_status_code': status,
        'client_ip':       fields[3].split(':')[0],
        'request':         fields[12].strip('"'),
        'user_agent':      fields[13].strip('"') if len(fields) > 13 else '-',
        'response_time_ms': resp_ms,
    }

def lambda_handler(event, context):
    records = []

    for s3_record in event['Records']:
        bucket = s3_record['s3']['bucket']['name']
        key    = s3_record['s3']['object']['key']
        obj    = s3_client.get_object(Bucket=bucket, Key=key)
        body   = gzip.decompress(obj['Body'].read()).decode('utf-8')

        for line in body.splitlines():
            if not line or line.startswith('#'):
                continue
            parsed = parse_line(line)
            if parsed:
                records.append({'Data': (json.dumps(parsed) + '\n').encode()})

            # Firehose PutRecordBatch 최대 500건
            if len(records) >= 500:
                firehose.put_record_batch(DeliveryStreamName=FIREHOSE_STREAM, Records=records)
                records = []

    if records:
        firehose.put_record_batch(DeliveryStreamName=FIREHOSE_STREAM, Records=records)

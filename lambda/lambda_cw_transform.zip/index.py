import base64, gzip, json, re
from datetime import datetime, timezone

CATEGORY_MAP = [
    ('/aws/cloudtrail/',         'Audit'),
    ('/aws/dms/',                'Migration'),
    ('dms-tasks-',               'Migration'),
    ('/threetier/vpc-flow-logs', 'Infrastructure'),
    ('/aws/rds/',                'Application'),
    ('/aws/apigateway/',         'Access'),
    ('/aws/lambda/',             'Application'),
    ('/ecs/',                    'Application'),
    ('aws-waf-logs',             'Application'),
]

LEVEL_RE = re.compile(r'\b(FATAL|CRITICAL|ERROR|WARN(?:ING)?|INFO|DEBUG|TRACE)\b', re.IGNORECASE)
LEVEL_RANK = {'FATAL': 5, 'CRITICAL': 4, 'ERROR': 3, 'WARN': 2, 'INFO': 1, 'DEBUG': 0, 'TRACE': 0}

def get_category(log_group):
    for prefix, cat in CATEGORY_MAP:
        if prefix in log_group:
            return cat
    return 'Application'

def get_service(log_group):
    return log_group.rstrip('/').split('/')[-1]

def get_level(message):
    m = LEVEL_RE.search(message)
    if not m:
        return 'INFO'
    lvl = m.group(1).upper()
    return 'WARN' if lvl == 'WARNING' else lvl

def lambda_handler(event, context):
    output = []
    for record in event['records']:
        raw = base64.b64decode(record['data'])

        # ALB Lambda puts pre-formatted JSON directly to Firehose (not gzip)
        try:
            log_data = json.loads(gzip.decompress(raw))
        except (gzip.BadGzipFile, OSError):
            output.append({'recordId': record['recordId'], 'result': 'Ok', 'data': record['data']})
            continue

        if log_data.get('messageType') == 'CONTROL_MESSAGE':
            output.append({'recordId': record['recordId'], 'result': 'Dropped', 'data': record['data']})
            continue

        category = get_category(log_data['logGroup'])
        service  = get_service(log_data['logGroup'])
        events   = log_data.get('logEvents', [])

        if not events:
            output.append({'recordId': record['recordId'], 'result': 'Dropped', 'data': record['data']})
            continue

        # Firehose 1-record-in → 1-record-out 제약: 배치 중 가장 높은 레벨 이벤트 하나만 반환
        best = max(events, key=lambda e: LEVEL_RANK.get(get_level(e['message']), 1))
        doc = json.dumps({
            'timestamp':   datetime.fromtimestamp(best['timestamp'] / 1000, tz=timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z',
            'logGroup':    log_data['logGroup'],
            'logStream':   log_data['logStream'],
            'category':    category,
            'service':     service,
            'level':       get_level(best['message']),
            'message':     best['message'],
            'event_count': len(events),
        })
        encoded = base64.b64encode((doc + '\n').encode()).decode()
        output.append({'recordId': record['recordId'], 'result': 'Ok', 'data': encoded})

    return {'records': output}

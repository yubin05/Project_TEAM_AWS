import base64, gzip, json, re

# logGroup → 카테고리 매핑
CATEGORY_MAP = [
    ('/aws/cloudtrail/',         'Audit'),
    ('/threetier/vpc-flow-logs', 'Infrastructure'),
    ('/aws/apigateway/',         'Access'),
    ('/aws/lambda/',             'Application'),
    ('/ecs/',                    'Application'),
    ('aws-waf-logs',             'Application'),
]

# 로그 레벨 키워드 추출 (대소문자 무관)
LEVEL_RE = re.compile(r'\b(FATAL|CRITICAL|ERROR|WARN(?:ING)?|INFO|DEBUG|TRACE)\b', re.IGNORECASE)

def get_category(log_group):
    for prefix, cat in CATEGORY_MAP:
        if prefix in log_group:
            return cat
    return 'Application'

def get_service(log_group):
    # /ecs/booking-service    → booking-service
    # /aws/lambda/image-resize → image-resize
    # /aws/apigateway/threetier-http-api → threetier-http-api
    return log_group.rstrip('/').split('/')[-1]

def get_level(message):
    m = LEVEL_RE.search(message)
    if not m:
        return 'INFO'
    lvl = m.group(1).upper()
    return 'WARN' if lvl == 'WARNING' else lvl

def lambda_handler(event, context):
    output = []
    for record in event['records']:
        compressed = base64.b64decode(record['data'])
        log_data   = json.loads(gzip.decompress(compressed))

        if log_data.get('messageType') == 'CONTROL_MESSAGE':
            output.append({'recordId': record['recordId'], 'result': 'Dropped', 'data': record['data']})
            continue

        category = get_category(log_data['logGroup'])
        service  = get_service(log_data['logGroup'])
        lines = []
        for ev in log_data.get('logEvents', []):
            message = ev['message']
            lines.append(json.dumps({
                'timestamp': ev['timestamp'],
                'logGroup':  log_data['logGroup'],
                'logStream': log_data['logStream'],
                'category':  category,
                'service':   service,
                'level':     get_level(message),
                'message':   message
            }))

        if lines:
            encoded = base64.b64encode(('\n'.join(lines) + '\n').encode()).decode()
            output.append({'recordId': record['recordId'], 'result': 'Ok', 'data': encoded})
        else:
            output.append({'recordId': record['recordId'], 'result': 'Dropped', 'data': record['data']})

    return {'records': output}
